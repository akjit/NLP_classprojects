#!/bin/bash
python run.py "$@"
